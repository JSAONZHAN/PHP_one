## 作业

做一个轮播出来（不会的看这个：http://www.imooc.com/learn/18）

要求：

1. 做出要求1.png那种样式（有箭头，有导航圆点）
2. 导航圆点绑定的点击事件使用事件委托（event.target）
3. 获取dom元素使用document.querySelector()和document.querySelectorAll();
4. 绑定事件的方法使用addEventListener（事件监听）




审核：

```
周五24:00之前把你们作业的git仓库地址发到yangxiaohan@redrock.team
发邮件邮件名格式：姓名-学号-学院
```



作业进阶（为学有余力的同学准备）

```
1.别出现类似跳帧的状况。
2. 去用css3（transition）和javascript把这个作业做出来。
要求：别出现图片回滚（就是从左往右滑动图片时，最后一张图片突然从右往左滑到第一张）
```

